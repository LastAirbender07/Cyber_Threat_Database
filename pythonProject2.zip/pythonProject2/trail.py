import math

def areaOfTriangle(a, b, c):
    s = (a + b + c) / 2
    product = s * (s - a) * (s - b) * (s - c)
    if product > 0:
        area = math.sqrt(product)
    else:
        area = 0
    return area